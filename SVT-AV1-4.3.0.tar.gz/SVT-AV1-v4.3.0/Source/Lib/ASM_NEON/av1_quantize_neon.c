/*
 * Copyright (c) 2023, Alliance for Open Media. All rights reserved
 *
 * This source code is subject to the terms of the BSD 2 Clause License and
 * the Alliance for Open Media Patent License 1.0. If the BSD 2 Clause License
 * was not distributed with this source code in the LICENSE file, you can
 * obtain it at www.aomedia.org/license/software. If the Alliance for Open
 * Media Patent License 1.0 was not distributed with this source code in the
 * PATENTS file, you can obtain it at www.aomedia.org/license/patent.
 */

#include <arm_neon.h>
#include <assert.h>
#include <math.h>

#include "aom_dsp_rtcd.h"
#include "inv_transforms.h"
#include "mem_neon.h"
#include "sum_neon.h"
#include "utility.h"

static inline uint16_t get_max_eob(int16x8_t v_eobmax) {
    int16_t max_val = vmaxvq_s16(v_eobmax);
    return (uint16_t)max_val + 1;
}

static inline int16x8_t get_max_lane_eob(const int16_t* iscan, int16x8_t v_eobmax, uint16x8_t v_mask) {
    const int16x8_t v_iscan    = vld1q_s16(iscan);
    const int16x8_t v_nz_iscan = vbslq_s16(v_mask, v_iscan, vdupq_n_s16(-1));
    return vmaxq_s16(v_eobmax, v_nz_iscan);
}

static inline uint16x8_t quantize_fp_8(const TranLow* coeff_ptr, TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                       int16x8_t v_quant, int16x8_t v_dequant, int16x8_t v_round, int16x8_t v_zero) {
    const int16x8_t  v_coeff      = load_tran_low_to_s16q(coeff_ptr);
    const int16x8_t  v_coeff_sign = vshrq_n_s16(v_coeff, 15);
    const int16x8_t  v_abs        = vabsq_s16(v_coeff);
    const int16x8_t  v_tmp        = vqaddq_s16(v_abs, v_round);
    const int16x8_t  v_tmp2       = vshrq_n_s16(vqdmulhq_s16(v_tmp, v_quant), 1);
    const uint16x8_t v_nz_mask    = vcgtq_s16(v_tmp2, v_zero);
    const int16x8_t  v_qcoeff_a   = veorq_s16(v_tmp2, v_coeff_sign);
    const int16x8_t  v_qcoeff     = vsubq_s16(v_qcoeff_a, v_coeff_sign);
    const int16x8_t  v_dqcoeff    = vmulq_s16(v_qcoeff, v_dequant);
    store_s16q_to_tran_low(qcoeff_ptr, v_qcoeff);
    store_s16q_to_tran_low(dqcoeff_ptr, v_dqcoeff);
    return v_nz_mask;
}

void svt_av1_quantize_fp_neon(const TranLow* coeff_ptr, intptr_t count, const int16_t* zbin_ptr,
                              const int16_t* round_ptr, const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                              TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr, const int16_t* dequant_ptr, uint16_t* eob_ptr,
                              const int16_t* scan, const int16_t* iscan) {
    (void)zbin_ptr;
    (void)quant_shift_ptr;
    (void)scan;

    // Quantization pass: All coefficients with index >= zero_flag are
    // skippable. Note: zero_flag can be zero.
    const int16x8_t v_zero            = vdupq_n_s16(0);
    int16x8_t       v_quant           = vld1q_s16(quant_ptr);
    int16x8_t       v_dequant         = vld1q_s16(dequant_ptr);
    int16x8_t       v_round           = vld1q_s16(round_ptr);
    int16x8_t       v_eobmax_76543210 = vdupq_n_s16(-1);
    uint16x8_t      v_nz_mask;
    // process dc and the first seven ac coeffs
    v_nz_mask         = quantize_fp_8(coeff_ptr, qcoeff_ptr, dqcoeff_ptr, v_quant, v_dequant, v_round, v_zero);
    v_eobmax_76543210 = get_max_lane_eob(iscan, v_eobmax_76543210, v_nz_mask);
    // overwrite the dc constants with ac constants
    v_quant   = vdupq_lane_s16(vget_low_s16(v_quant), 1);
    v_dequant = vdupq_lane_s16(vget_low_s16(v_dequant), 1);
    v_round   = vdupq_lane_s16(vget_low_s16(v_round), 1);

    count -= 8;
    // now process the rest of the ac coeffs
    do {
        coeff_ptr += 8;
        qcoeff_ptr += 8;
        dqcoeff_ptr += 8;
        iscan += 8;
        v_nz_mask         = quantize_fp_8(coeff_ptr, qcoeff_ptr, dqcoeff_ptr, v_quant, v_dequant, v_round, v_zero);
        v_eobmax_76543210 = get_max_lane_eob(iscan, v_eobmax_76543210, v_nz_mask);
        count -= 8;
    } while (count > 0);
    *eob_ptr = get_max_eob(v_eobmax_76543210);
}

static AOM_FORCE_INLINE uint16x8_t quantize_fp_logscale_8(const TranLow* coeff_ptr, TranLow* qcoeff_ptr,
                                                          TranLow* dqcoeff_ptr, int16x8_t v_quant, int16x8_t v_dequant,
                                                          int16x8_t v_round, int16x8_t v_zero, int log_scale) {
    const int16x8_t  v_log_scale_minus_1    = vdupq_n_s16(log_scale - 1);
    const int16x8_t  v_neg_log_scale_plus_1 = vdupq_n_s16(-(1 + log_scale));
    const int16x8_t  v_coeff                = load_tran_low_to_s16q(coeff_ptr);
    const int16x8_t  v_coeff_sign           = vshrq_n_s16(v_coeff, 15);
    const int16x8_t  v_abs_coeff            = vabsq_s16(v_coeff);
    const uint16x8_t v_mask                 = vcgeq_s16(v_abs_coeff, vshlq_s16(v_dequant, v_neg_log_scale_plus_1));
    // const int64_t tmp = vmask ? (int64_t)abs_coeff + log_scaled_round : 0
    const int16x8_t  v_tmp     = vandq_s16(vqaddq_s16(v_abs_coeff, v_round), vreinterpretq_s16_u16(v_mask));
    const int16x8_t  v_tmp2    = vqdmulhq_s16(vshlq_s16(v_tmp, v_log_scale_minus_1), v_quant);
    const uint16x8_t v_nz_mask = vcgtq_s16(v_tmp2, v_zero);
    const int16x8_t  v_qcoeff  = vsubq_s16(veorq_s16(v_tmp2, v_coeff_sign), v_coeff_sign);
    // Multiplying by dequant here will use all 16 bits. Cast to unsigned before
    // shifting right. (vshlq_s16 will shift right if shift value is negative)
    const uint16x8_t v_abs_dqcoeff = vshlq_u16(vreinterpretq_u16_s16(vmulq_s16(v_tmp2, v_dequant)),
                                               vdupq_n_s16(-log_scale));
    const int16x8_t  v_dqcoeff = vsubq_s16(veorq_s16(vreinterpretq_s16_u16(v_abs_dqcoeff), v_coeff_sign), v_coeff_sign);
    store_s16q_to_tran_low(qcoeff_ptr, v_qcoeff);
    store_s16q_to_tran_low(dqcoeff_ptr, v_dqcoeff);
    return v_nz_mask;
}

static AOM_FORCE_INLINE uint16x8_t quantize_fp_logscale2_8(const TranLow* coeff_ptr, TranLow* qcoeff_ptr,
                                                           TranLow* dqcoeff_ptr, int16x8_t v_quant, int16x8_t v_dequant,
                                                           int16x8_t v_round, int16x8_t v_zero) {
    const int16x8_t  v_coeff      = load_tran_low_to_s16q(coeff_ptr);
    const int16x8_t  v_coeff_sign = vshrq_n_s16(v_coeff, 15);
    const int16x8_t  v_abs_coeff  = vabsq_s16(v_coeff);
    const uint16x8_t v_mask       = vcgeq_u16(vshlq_n_u16(vreinterpretq_u16_s16(v_abs_coeff), 1),
                                              vshrq_n_u16(vreinterpretq_u16_s16(v_dequant), 2));
    // abs_coeff = vmask ? (int64_t)abs_coeff + log_scaled_round : 0
    const int16x8_t v_tmp = vandq_s16(vqaddq_s16(v_abs_coeff, v_round), vreinterpretq_s16_u16(v_mask));
    // tmp32 = (int)((abs_coeff * quant_ptr[rc != 0]) >> (16 - log_scale));
    const int16x8_t v_tmp2 = vorrq_s16(
        vshlq_n_s16(vqdmulhq_s16(v_tmp, v_quant), 1),
        vreinterpretq_s16_u16(vshrq_n_u16(vreinterpretq_u16_s16(vmulq_s16(v_tmp, v_quant)), 14)));
    const uint16x8_t v_nz_mask = vcgtq_s16(v_tmp2, v_zero);
    const int16x8_t  v_qcoeff  = vsubq_s16(veorq_s16(v_tmp2, v_coeff_sign), v_coeff_sign);
    // const TranLow abs_dqcoeff = (tmp32 * dequant_ptr[rc != 0]) >> log_scale;
    const int16x8_t v_abs_dqcoeff = vorrq_s16(
        vshlq_n_s16(vqdmulhq_s16(v_tmp2, v_dequant), 13),
        vreinterpretq_s16_u16(vshrq_n_u16(vreinterpretq_u16_s16(vmulq_s16(v_tmp2, v_dequant)), 2)));
    const int16x8_t v_dqcoeff = vsubq_s16(veorq_s16(v_abs_dqcoeff, v_coeff_sign), v_coeff_sign);
    store_s16q_to_tran_low(qcoeff_ptr, v_qcoeff);
    store_s16q_to_tran_low(dqcoeff_ptr, v_dqcoeff);
    return v_nz_mask;
}

static AOM_FORCE_INLINE void quantize_fp_no_qmatrix_neon(const TranLow* coeff_ptr, intptr_t n_coeffs,
                                                         const int16_t* round_ptr, const int16_t* quant_ptr,
                                                         TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                                         const int16_t* dequant_ptr, uint16_t* eob_ptr,
                                                         const int16_t* iscan, int log_scale) {
    const int16x8_t v_zero            = vdupq_n_s16(0);
    int16x8_t       v_quant           = vld1q_s16(quant_ptr);
    int16x8_t       v_dequant         = vld1q_s16(dequant_ptr);
    const int16x8_t v_round_no_scale  = vld1q_s16(round_ptr);
    int16x8_t       v_round           = vqrdmulhq_n_s16(v_round_no_scale, (int16_t)(1 << (15 - log_scale)));
    int16x8_t       v_eobmax_76543210 = vdupq_n_s16(-1);
    intptr_t        non_zero_count    = n_coeffs;

    assert(n_coeffs > 16);
    // Pre-scan pass. Zero the skipped chunks in place as we go: fusing the store into the scan is
    // markedly faster on sparse blocks than memset-ing the whole tail afterwards, and free when nothing
    // is skipped.
    const int16x8_t v_dequant_scaled = vshlq_s16(v_dequant, vdupq_n_s16(-(1 + log_scale)));
    const int16x8_t v_zbin_s16       = vdupq_lane_s16(vget_low_s16(v_dequant_scaled), 1);
    const int32x4_t v_zero32         = vdupq_n_s32(0);
    intptr_t        i                = n_coeffs;
    do {
        const int16x8_t  v_coeff_a     = load_tran_low_to_s16q(coeff_ptr + i - 8);
        const int16x8_t  v_coeff_b     = load_tran_low_to_s16q(coeff_ptr + i - 16);
        const int16x8_t  v_abs_coeff_a = vabsq_s16(v_coeff_a);
        const int16x8_t  v_abs_coeff_b = vabsq_s16(v_coeff_b);
        const uint16x8_t v_mask_a      = vcgeq_s16(v_abs_coeff_a, v_zbin_s16);
        const uint16x8_t v_mask_b      = vcgeq_s16(v_abs_coeff_b, v_zbin_s16);
        // If the coefficient is in the base ZBIN range, then discard.
        if (horizontal_long_add_u16x8(v_mask_a, v_mask_b) != 0) {
            break;
        }
        vst1q_s32(qcoeff_ptr + i - 4, v_zero32);
        vst1q_s32(qcoeff_ptr + i - 8, v_zero32);
        vst1q_s32(qcoeff_ptr + i - 12, v_zero32);
        vst1q_s32(qcoeff_ptr + i - 16, v_zero32);
        vst1q_s32(dqcoeff_ptr + i - 4, v_zero32);
        vst1q_s32(dqcoeff_ptr + i - 8, v_zero32);
        vst1q_s32(dqcoeff_ptr + i - 12, v_zero32);
        vst1q_s32(dqcoeff_ptr + i - 16, v_zero32);
        non_zero_count -= 16;
        i -= 16;
    } while (i > 0);

    // process dc and the first seven ac coeffs
    uint16x8_t v_nz_mask;
    if (log_scale == 2) {
        v_nz_mask = quantize_fp_logscale2_8(coeff_ptr, qcoeff_ptr, dqcoeff_ptr, v_quant, v_dequant, v_round, v_zero);
    } else {
        v_nz_mask = quantize_fp_logscale_8(
            coeff_ptr, qcoeff_ptr, dqcoeff_ptr, v_quant, v_dequant, v_round, v_zero, log_scale);
    }
    v_eobmax_76543210 = get_max_lane_eob(iscan, v_eobmax_76543210, v_nz_mask);
    // overwrite the dc constants with ac constants
    v_quant   = vdupq_lane_s16(vget_low_s16(v_quant), 1);
    v_dequant = vdupq_lane_s16(vget_low_s16(v_dequant), 1);
    v_round   = vdupq_lane_s16(vget_low_s16(v_round), 1);

    for (intptr_t count = non_zero_count - 8; count > 0; count -= 8) {
        coeff_ptr += 8;
        qcoeff_ptr += 8;
        dqcoeff_ptr += 8;
        iscan += 8;
        if (log_scale == 2) {
            v_nz_mask = quantize_fp_logscale2_8(
                coeff_ptr, qcoeff_ptr, dqcoeff_ptr, v_quant, v_dequant, v_round, v_zero);
        } else {
            v_nz_mask = quantize_fp_logscale_8(
                coeff_ptr, qcoeff_ptr, dqcoeff_ptr, v_quant, v_dequant, v_round, v_zero, log_scale);
        }
        v_eobmax_76543210 = get_max_lane_eob(iscan, v_eobmax_76543210, v_nz_mask);
    }
    *eob_ptr = get_max_eob(v_eobmax_76543210);
}

void svt_av1_quantize_fp_32x32_neon(const TranLow* coeff_ptr, intptr_t n_coeffs, const int16_t* zbin_ptr,
                                    const int16_t* round_ptr, const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                    TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr, const int16_t* dequant_ptr,
                                    uint16_t* eob_ptr, const int16_t* scan, const int16_t* iscan) {
    (void)zbin_ptr;
    (void)quant_shift_ptr;
    (void)scan;
    quantize_fp_no_qmatrix_neon(
        coeff_ptr, n_coeffs, round_ptr, quant_ptr, qcoeff_ptr, dqcoeff_ptr, dequant_ptr, eob_ptr, iscan, 1);
}

void svt_av1_quantize_fp_64x64_neon(const TranLow* coeff_ptr, intptr_t n_coeffs, const int16_t* zbin_ptr,
                                    const int16_t* round_ptr, const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                    TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr, const int16_t* dequant_ptr,
                                    uint16_t* eob_ptr, const int16_t* scan, const int16_t* iscan) {
    (void)zbin_ptr;
    (void)quant_shift_ptr;
    (void)scan;
    quantize_fp_no_qmatrix_neon(
        coeff_ptr, n_coeffs, round_ptr, quant_ptr, qcoeff_ptr, dqcoeff_ptr, dequant_ptr, eob_ptr, iscan, 2);
}

// Quantize 4 coefficients (one int32x4 lane group) using a quantization matrix (fast-quantize path).
// Mirrors the scalar reference quantize_fp_helper_c() qm path and the AVX2 quantize_qm() kernel.
// `highbd` is a compile-time constant selecting only the int16 clamp: the 8-bit forward path clamps
// (abs_coeff + round) to int16 to bit-match the int16-lane SIMD kernels, while the high-bit-depth
// helpers (highbd_quantize_fp_helper_c) leave abs_coeff unclamped. The quant multiply itself is the
// same 32-bit doubling multiply-high at every bit depth -- vqdmulhq_s32 holds the wide product in its
// internal 64-bit accumulator, so no widening to 64-bit lanes is needed (see the range note below).
// Returns a per-lane non-zero mask (abs_qcoeff != 0, matching the C reference's EOB rule).
static AOM_FORCE_INLINE uint32x4_t quantize_fp_qm_4(int32x4_t v_coeff, int32x4_t v_qm, int32x4_t v_iqm,
                                                    int32x4_t v_round, int32x4_t v_q_scale, int32x4_t v_dequant,
                                                    int32x4_t v_thr, TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                                    int log_scale, const int highbd) {
    const int32x4_t v_sign = vshrq_n_s32(v_coeff, 31);
    const int32x4_t v_abs  = vabsq_s32(v_coeff);
    // Below-threshold lanes are forced to zero. C: abs_coeff * wt >= (dequant << (AOM_QM_BITS - (1 + log_scale)))
    const int32x4_t  v_coeff_wt = vmulq_s32(v_abs, v_qm);
    const uint32x4_t v_below    = vcgtq_s32(v_thr, v_coeff_wt);

    // Sparse-block shortcut (mirrors the AVX2 quantize_qm() below-threshold early-out): when every lane in
    // the group is below the gate threshold the whole group quantizes to zero, so store zeros and skip the
    // quant math. Bit-exact -- the full path vbic's these lanes to zero anyway. Common in lossy coding.
    if (vminvq_u32(v_below) == 0xFFFFFFFFu) {
        vst1q_s32(qcoeff_ptr, vdupq_n_s32(0));
        vst1q_s32(dqcoeff_ptr, vdupq_n_s32(0));
        return vdupq_n_u32(0);
    }

    // abs_qcoeff = ((abs_coeff + round) * wt * quant) >> (16 - log_scale + AOM_QM_BITS). The "* quant >> S"
    // step folds into a doubling multiply-high: vqdmulhq_s32(p, v_q_scale) == (p * quant) >> S (truncating,
    // matching the C >>), with the wide product held in the SQDMULH accumulator. v_q_scale = quant <<
    // (31 - S) is loop-invariant, so the caller precomputes it once. The 32-bit-lane operands p = (abs +
    // round) * wt and v_q_scale both stay inside int32 at every bit depth (|coeff| < 1 << (7 + bd), wt <=
    // 255 so p <= 2^27; quant <= 16384, S = 21 - log_scale so v_q_scale <= 2^27). One path serves
    // 8/10/12-bit; only the 8-bit int16 clamp differs (highbd leaves abs_coeff unclamped, matching it).
    int32x4_t v_q = vaddq_s32(v_abs, v_round);
    if (!highbd) {
        v_q = vminq_s32(v_q, vdupq_n_s32(32767));
    }
    // Zero the below-threshold lanes once, here; the zeros propagate through the quant to qcoeff and
    // dqcoeff, so no separate output masking is needed.
    v_q                      = vbicq_s32(v_q, vreinterpretq_s32_u32(v_below));
    const int32x4_t v_p      = vmulq_s32(v_q, v_qm);
    int32x4_t       v_qcoeff = vqdmulhq_s32(v_p, v_q_scale);

    // dequant_qm = (dequant * iqm + (1 << (AOM_QM_BITS - 1))) >> AOM_QM_BITS; abs_dqcoeff = (abs_qcoeff * dequant_qm) >> log_scale.
    // The C reference computes this product in int32 at every bit depth, so keep it in 32-bit lanes; a
    // wider synthetic abs_qcoeff wraps mod 2^32 identically to the reference (real coefficients never overflow).
    int32x4_t v_dqf     = vmulq_s32(v_dequant, v_iqm);
    v_dqf               = vrshrq_n_s32(v_dqf, AOM_QM_BITS);
    int32x4_t v_dqcoeff = vshlq_s32(vmulq_s32(v_qcoeff, v_dqf), vdupq_n_s32(-log_scale));

    // Per-lane nonzero mask (abs_qcoeff != 0; below-threshold lanes are already zero), scanned for the EOB.
    const uint32x4_t v_nz = vbicq_u32(vmvnq_u32(vceqzq_s32(v_qcoeff)), v_below);

    // Restore sign (below-threshold lanes were zeroed before the quant, so they stay zero).
    v_qcoeff  = vsubq_s32(veorq_s32(v_qcoeff, v_sign), v_sign);
    v_dqcoeff = vsubq_s32(veorq_s32(v_dqcoeff, v_sign), v_sign);

    vst1q_s32(qcoeff_ptr, v_qcoeff);
    vst1q_s32(dqcoeff_ptr, v_dqcoeff);
    return v_nz;
}

// Build a per-lane parameter vector holding the DC value in lane 0 and the AC value in lanes 1..3.
static AOM_FORCE_INLINE int32x4_t dc_ac_s32(int32_t dc, int32_t ac) {
    return vsetq_lane_s32(dc, vdupq_n_s32(ac), 0);
}

static AOM_FORCE_INLINE void quantize_fp_qm_neon_impl(const TranLow* coeff_ptr, intptr_t n_coeffs,
                                                      const int16_t* round_ptr, const int16_t* quant_ptr,
                                                      TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                                      const int16_t* dequant_ptr, uint16_t* eob_ptr,
                                                      const int16_t* iscan, const QmVal* qm_ptr, const QmVal* iqm_ptr,
                                                      int log_scale, const int highbd) {
    assert(qm_ptr != NULL && iqm_ptr != NULL);
    assert(n_coeffs >= 16 && (n_coeffs & 7) == 0);

    const int       shift_q      = 16 - log_scale + AOM_QM_BITS;
    const int       thr_sh       = AOM_QM_BITS - (1 + log_scale);
    const int32_t   rnd_dc       = log_scale > 0 ? (round_ptr[0] + (1 << (log_scale - 1))) >> log_scale : round_ptr[0];
    const int32_t   rnd_ac       = log_scale > 0 ? (round_ptr[1] + (1 << (log_scale - 1))) >> log_scale : round_ptr[1];
    const int32x4_t v_round_ac   = vdupq_n_s32(rnd_ac);
    const int32x4_t v_quant_ac   = vdupq_n_s32(quant_ptr[1]);
    const int32x4_t v_dequant_ac = vdupq_n_s32(dequant_ptr[1]);
    const int32x4_t v_thr_ac     = vshlq_s32(v_dequant_ac, vdupq_n_s32(thr_sh));
    // quant << (31 - shift_q) is loop-invariant; precompute it once instead of per coefficient group.
    const int       qsh         = 31 - shift_q;
    const int32x4_t v_qscale_ac = vshlq_s32(v_quant_ac, vdupq_n_s32(qsh));

    int16x8_t v_eobmax = vdupq_n_s16(-1);

    // First group of 8: lane 0 of the low half carries the DC quant constants, the rest use AC.
    int32x4_t v_round_lo   = dc_ac_s32(rnd_dc, rnd_ac);
    int32x4_t v_quant_lo   = dc_ac_s32(quant_ptr[0], quant_ptr[1]);
    int32x4_t v_dequant_lo = dc_ac_s32(dequant_ptr[0], dequant_ptr[1]);
    int32x4_t v_thr_lo     = vshlq_s32(v_dequant_lo, vdupq_n_s32(thr_sh));
    int32x4_t v_qscale_lo  = vshlq_s32(v_quant_lo, vdupq_n_s32(qsh));

    intptr_t i = 0;
    for (;;) {
        const uint16x8_t v_qm     = vmovl_u8(vld1_u8(qm_ptr + i));
        const uint16x8_t v_iqm    = vmovl_u8(vld1_u8(iqm_ptr + i));
        const int32x4_t  v_qm_lo  = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(v_qm)));
        const int32x4_t  v_qm_hi  = vreinterpretq_s32_u32(vmovl_high_u16(v_qm));
        const int32x4_t  v_iqm_lo = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(v_iqm)));
        const int32x4_t  v_iqm_hi = vreinterpretq_s32_u32(vmovl_high_u16(v_iqm));

        const uint32x4_t nz_lo     = quantize_fp_qm_4(vld1q_s32(coeff_ptr + i),
                                                      v_qm_lo,
                                                      v_iqm_lo,
                                                      v_round_lo,
                                                      v_qscale_lo,
                                                      v_dequant_lo,
                                                      v_thr_lo,
                                                      qcoeff_ptr + i,
                                                      dqcoeff_ptr + i,
                                                      log_scale,
                                                      highbd);
        const uint32x4_t nz_hi     = quantize_fp_qm_4(vld1q_s32(coeff_ptr + i + 4),
                                                      v_qm_hi,
                                                      v_iqm_hi,
                                                      v_round_ac,
                                                      v_qscale_ac,
                                                      v_dequant_ac,
                                                      v_thr_ac,
                                                      qcoeff_ptr + i + 4,
                                                      dqcoeff_ptr + i + 4,
                                                      log_scale,
                                                      highbd);
        const uint16x8_t v_nz_mask = vcombine_u16(vmovn_u32(nz_lo), vmovn_u32(nz_hi));
        v_eobmax                   = get_max_lane_eob(iscan + i, v_eobmax, v_nz_mask);

        i += 8;
        if (i >= n_coeffs) {
            break;
        }
        // All subsequent lanes use AC constants.
        v_round_lo   = v_round_ac;
        v_qscale_lo  = v_qscale_ac;
        v_dequant_lo = v_dequant_ac;
        v_thr_lo     = v_thr_ac;
    }
    *eob_ptr = get_max_eob(v_eobmax);
}

void svt_av1_quantize_fp_qm_neon(const TranLow* coeff_ptr, intptr_t n_coeffs, const int16_t* zbin_ptr,
                                 const int16_t* round_ptr, const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                 TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr, const int16_t* dequant_ptr,
                                 uint16_t* eob_ptr, const int16_t* scan, const int16_t* iscan, const QmVal* qm_ptr,
                                 const QmVal* iqm_ptr, int16_t log_scale) {
    (void)zbin_ptr;
    (void)quant_shift_ptr;
    (void)scan;
    quantize_fp_qm_neon_impl(coeff_ptr,
                             n_coeffs,
                             round_ptr,
                             quant_ptr,
                             qcoeff_ptr,
                             dqcoeff_ptr,
                             dequant_ptr,
                             eob_ptr,
                             iscan,
                             qm_ptr,
                             iqm_ptr,
                             log_scale,
                             /*highbd=*/0);
}

void svt_av1_highbd_quantize_fp_qm_neon(const TranLow* coeff_ptr, intptr_t n_coeffs, const int16_t* zbin_ptr,
                                        const int16_t* round_ptr, const int16_t* quant_ptr,
                                        const int16_t* quant_shift_ptr, TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                        const int16_t* dequant_ptr, uint16_t* eob_ptr, const int16_t* scan,
                                        const int16_t* iscan, const QmVal* qm_ptr, const QmVal* iqm_ptr,
                                        int16_t log_scale) {
    (void)zbin_ptr;
    (void)quant_shift_ptr;
    (void)scan;
    quantize_fp_qm_neon_impl(coeff_ptr,
                             n_coeffs,
                             round_ptr,
                             quant_ptr,
                             qcoeff_ptr,
                             dqcoeff_ptr,
                             dequant_ptr,
                             eob_ptr,
                             iscan,
                             qm_ptr,
                             iqm_ptr,
                             log_scale,
                             /*highbd=*/1);
}

// Quantize 4 coefficients (one int32x4 lane group) for the quantize_b qm path.
// Mirrors svt_aom_quantize_b_c()'s qm branch and the AVX2 quantize_qm() kernel: the two-step quantizer
// ((q*wt*quant) >> 16 + q*wt) * quant_shift, kept in 32-bit lanes via doubling multiply-highs. Returns a
// per-lane non-zero mask derived from abs_qcoeff (matching the C reference's EOB rule).
static AOM_FORCE_INLINE uint32x4_t quantize_b_qm_4(int32x4_t v_coeff, int32x4_t v_qm, int32x4_t v_iqm,
                                                   int32x4_t v_round, int32x4_t v_quant_scl, int32x4_t v_qshift_scl,
                                                   int32x4_t v_dequant, int32x4_t v_zbin_thr, TranLow* qcoeff_ptr,
                                                   TranLow* dqcoeff_ptr, int log_scale, const int highbd) {
    const int32x4_t v_sign = vshrq_n_s32(v_coeff, 31);
    const int32x4_t v_abs  = vabsq_s32(v_coeff);
    // Below-ZBIN lanes are forced to zero. C: abs_coeff * wt >= (zbins[rc != 0] << AOM_QM_BITS)
    const int32x4_t  v_abs_wt = vmulq_s32(v_abs, v_qm);
    const uint32x4_t v_below  = vcgtq_s32(v_zbin_thr, v_abs_wt);

    // Sparse-block shortcut (mirrors the AVX2 quantize_qm() below-threshold early-out): when every lane in
    // the group is below the ZBIN gate the whole group quantizes to zero, so store zeros and skip the
    // two-step quant math. Bit-exact -- the full path vbic's these lanes to zero anyway.
    if (vminvq_u32(v_below) == 0xFFFFFFFFu) {
        vst1q_s32(qcoeff_ptr, vdupq_n_s32(0));
        vst1q_s32(dqcoeff_ptr, vdupq_n_s32(0));
        return vdupq_n_u32(0);
    }

    // Two-step quantizer, both "(x * y) >> n" steps folded into doubling multiply-highs so the wide
    // products stay inside the SQDMULH accumulators (no widening to 64-bit lanes):
    //   step1: (q_wt * quant) >> 16      == vqdmulhq_s32(q_wt, v_quant_scl),  v_quant_scl  = quant << 15
    //   abs_q: (q2 * quant_shift) >> S    == vqdmulhq_s32(q2, v_qshift_scl),  v_qshift_scl = quant_shift << (31 - S)
    // Both scales are loop-invariant, so the caller precomputes them once. The 32-bit-lane operands all
    // stay inside int32 at every bit depth: with |coeff| < 1 << (7 + bd) and wt a uint8 (<= 255), q_wt =
    // (abs + round) * wt <= 2^27; quant is int16 so quant << 15 <= 2^30; q2 = step1 + q_wt <= 2^28;
    // quant_shift << (31 - S) <= 2^27. quant/quant_shift can be negative, but SQDMULH's high-half is an
    // arithmetic shift matching the C >>, and saturation is unreachable (no operand reaches INT32_MIN).
    // Only the 8-bit int16 clamp differs from the (unclamped) highbd path.
    int32x4_t v_q = vaddq_s32(v_abs, v_round);
    if (!highbd) {
        v_q = vminq_s32(v_q, vdupq_n_s32(32767));
    }
    // Zero the below-ZBIN lanes once, here; the zeros propagate through the two-step quant to qcoeff and
    // dqcoeff, so no separate output masking is needed.
    v_q                      = vbicq_s32(v_q, vreinterpretq_s32_u32(v_below));
    const int32x4_t v_q_wt   = vmulq_s32(v_q, v_qm);
    const int32x4_t v_step1  = vqdmulhq_s32(v_q_wt, v_quant_scl);
    const int32x4_t v_q2     = vaddq_s32(v_step1, v_q_wt);
    int32x4_t       v_qcoeff = vqdmulhq_s32(v_q2, v_qshift_scl);

    // dequant_qm = (dequant * iqm + (1 << (AOM_QM_BITS - 1))) >> AOM_QM_BITS; abs_dqcoeff = (abs_qcoeff * dequant_qm) >> log_scale.
    // The C reference computes this product in int32 at every bit depth, so keep it in 32-bit lanes; a
    // wider synthetic abs_qcoeff wraps mod 2^32 identically to the reference (real coefficients never overflow).
    int32x4_t v_dqf     = vmulq_s32(v_dequant, v_iqm);
    v_dqf               = vrshrq_n_s32(v_dqf, AOM_QM_BITS);
    int32x4_t v_dqcoeff = vshlq_s32(vmulq_s32(v_qcoeff, v_dqf), vdupq_n_s32(-log_scale));

    // Per-lane nonzero mask (abs_qcoeff != 0; below-ZBIN lanes excluded), scanned by the caller for the EOB.
    const uint32x4_t v_nz = vbicq_u32(vmvnq_u32(vceqzq_s32(v_qcoeff)), v_below);

    v_qcoeff  = vsubq_s32(veorq_s32(v_qcoeff, v_sign), v_sign);
    v_dqcoeff = vsubq_s32(veorq_s32(v_dqcoeff, v_sign), v_sign);
    vst1q_s32(qcoeff_ptr, v_qcoeff);
    vst1q_s32(dqcoeff_ptr, v_dqcoeff);
    return v_nz;
}

static AOM_FORCE_INLINE void quantize_b_qm_neon_impl(const TranLow* coeff_ptr, intptr_t n_coeffs,
                                                     const int16_t* zbin_ptr, const int16_t* round_ptr,
                                                     const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                                     TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                                     const int16_t* dequant_ptr, uint16_t* eob_ptr,
                                                     const int16_t* iscan, const QmVal* qm_ptr, const QmVal* iqm_ptr,
                                                     int log_scale, const int highbd) {
    assert(qm_ptr != NULL && iqm_ptr != NULL);
    assert(n_coeffs >= 16 && (n_coeffs & 7) == 0);

    const int     shift_q = 16 - log_scale + AOM_QM_BITS;
    const int32_t rnd_dc  = log_scale > 0 ? (round_ptr[0] + (1 << (log_scale - 1))) >> log_scale : round_ptr[0];
    const int32_t rnd_ac  = log_scale > 0 ? (round_ptr[1] + (1 << (log_scale - 1))) >> log_scale : round_ptr[1];
    const int32_t zbn_dc  = (log_scale > 0 ? (zbin_ptr[0] + (1 << (log_scale - 1))) >> log_scale : zbin_ptr[0])
        << AOM_QM_BITS;
    const int32_t zbn_ac = (log_scale > 0 ? (zbin_ptr[1] + (1 << (log_scale - 1))) >> log_scale : zbin_ptr[1])
        << AOM_QM_BITS;

    const int32x4_t v_round_ac    = vdupq_n_s32(rnd_ac);
    const int32x4_t v_quant_ac    = vdupq_n_s32(quant_ptr[1]);
    const int32x4_t v_qshift_ac   = vdupq_n_s32(quant_shift_ptr[1]);
    const int32x4_t v_dequant_ac  = vdupq_n_s32(dequant_ptr[1]);
    const int32x4_t v_zbin_thr_ac = vdupq_n_s32(zbn_ac);
    // quant << 15 and quant_shift << (31 - shift_q) are loop-invariant; precompute them once.
    const int       qsh             = 31 - shift_q;
    const int32x4_t v_quant_scl_ac  = vshlq_s32(v_quant_ac, vdupq_n_s32(15));
    const int32x4_t v_qshift_scl_ac = vshlq_s32(v_qshift_ac, vdupq_n_s32(qsh));

    int32x4_t v_round_lo      = dc_ac_s32(rnd_dc, rnd_ac);
    int32x4_t v_quant_lo      = dc_ac_s32(quant_ptr[0], quant_ptr[1]);
    int32x4_t v_qshift_lo     = dc_ac_s32(quant_shift_ptr[0], quant_shift_ptr[1]);
    int32x4_t v_dequant_lo    = dc_ac_s32(dequant_ptr[0], dequant_ptr[1]);
    int32x4_t v_zbin_thr_lo   = dc_ac_s32(zbn_dc, zbn_ac);
    int32x4_t v_quant_scl_lo  = vshlq_s32(v_quant_lo, vdupq_n_s32(15));
    int32x4_t v_qshift_scl_lo = vshlq_s32(v_qshift_lo, vdupq_n_s32(qsh));

    int16x8_t v_eobmax = vdupq_n_s16(-1);
    for (intptr_t i = 0;;) {
        const uint16x8_t v_qm     = vmovl_u8(vld1_u8(qm_ptr + i));
        const uint16x8_t v_iqm    = vmovl_u8(vld1_u8(iqm_ptr + i));
        const int32x4_t  v_qm_lo  = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(v_qm)));
        const int32x4_t  v_qm_hi  = vreinterpretq_s32_u32(vmovl_high_u16(v_qm));
        const int32x4_t  v_iqm_lo = vreinterpretq_s32_u32(vmovl_u16(vget_low_u16(v_iqm)));
        const int32x4_t  v_iqm_hi = vreinterpretq_s32_u32(vmovl_high_u16(v_iqm));

        const uint32x4_t nz_lo     = quantize_b_qm_4(vld1q_s32(coeff_ptr + i),
                                                     v_qm_lo,
                                                     v_iqm_lo,
                                                     v_round_lo,
                                                     v_quant_scl_lo,
                                                     v_qshift_scl_lo,
                                                     v_dequant_lo,
                                                     v_zbin_thr_lo,
                                                     qcoeff_ptr + i,
                                                     dqcoeff_ptr + i,
                                                     log_scale,
                                                     highbd);
        const uint32x4_t nz_hi     = quantize_b_qm_4(vld1q_s32(coeff_ptr + i + 4),
                                                     v_qm_hi,
                                                     v_iqm_hi,
                                                     v_round_ac,
                                                     v_quant_scl_ac,
                                                     v_qshift_scl_ac,
                                                     v_dequant_ac,
                                                     v_zbin_thr_ac,
                                                     qcoeff_ptr + i + 4,
                                                     dqcoeff_ptr + i + 4,
                                                     log_scale,
                                                     highbd);
        const uint16x8_t v_nz_mask = vcombine_u16(vmovn_u32(nz_lo), vmovn_u32(nz_hi));
        v_eobmax                   = get_max_lane_eob(iscan + i, v_eobmax, v_nz_mask);

        i += 8;
        if (i >= n_coeffs) {
            break;
        }
        v_round_lo      = v_round_ac;
        v_quant_scl_lo  = v_quant_scl_ac;
        v_qshift_scl_lo = v_qshift_scl_ac;
        v_dequant_lo    = v_dequant_ac;
        v_zbin_thr_lo   = v_zbin_thr_ac;
    }
    *eob_ptr = get_max_eob(v_eobmax);
}

void svt_av1_quantize_b_qm_neon(const TranLow* coeff_ptr, intptr_t n_coeffs, const int16_t* zbin_ptr,
                                const int16_t* round_ptr, const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr, const int16_t* dequant_ptr,
                                uint16_t* eob_ptr, const int16_t* scan, const int16_t* iscan, const QmVal* qm_ptr,
                                const QmVal* iqm_ptr, const int32_t log_scale) {
    (void)scan;
    quantize_b_qm_neon_impl(coeff_ptr,
                            n_coeffs,
                            zbin_ptr,
                            round_ptr,
                            quant_ptr,
                            quant_shift_ptr,
                            qcoeff_ptr,
                            dqcoeff_ptr,
                            dequant_ptr,
                            eob_ptr,
                            iscan,
                            qm_ptr,
                            iqm_ptr,
                            log_scale,
                            /*highbd=*/0);
}

void svt_av1_highbd_quantize_b_qm_neon(const TranLow* coeff_ptr, intptr_t n_coeffs, const int16_t* zbin_ptr,
                                       const int16_t* round_ptr, const int16_t* quant_ptr,
                                       const int16_t* quant_shift_ptr, TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                       const int16_t* dequant_ptr, uint16_t* eob_ptr, const int16_t* scan,
                                       const int16_t* iscan, const QmVal* qm_ptr, const QmVal* iqm_ptr,
                                       const int32_t log_scale) {
    (void)scan;
    quantize_b_qm_neon_impl(coeff_ptr,
                            n_coeffs,
                            zbin_ptr,
                            round_ptr,
                            quant_ptr,
                            quant_shift_ptr,
                            qcoeff_ptr,
                            dqcoeff_ptr,
                            dequant_ptr,
                            eob_ptr,
                            iscan,
                            qm_ptr,
                            iqm_ptr,
                            log_scale,
                            /*highbd=*/1);
}

static inline uint16x8_t quantize_b_logscale0_8(int16x8_t coeff, int16x8_t abs, uint16x8_t cond, int16x8_t round,
                                                int16x8_t dequant, int16x8_t quant, int16x8_t neg_shift,
                                                TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr) {
    int16x8_t coeff_sign = vreinterpretq_s16_u16(vcltzq_s16(coeff));

    int16x8_t tmp = vqaddq_s16(abs, round);
    tmp           = vsraq_n_s16(tmp, vqdmulhq_s16(tmp, quant), 1);
    tmp           = vshlq_s16(tmp, neg_shift);
    tmp           = vandq_s16(tmp, vreinterpretq_s16_u16(cond));

    int16x8_t qcoeff = vsubq_s16(veorq_s16(tmp, coeff_sign), coeff_sign);
    store_s16q_to_tran_low(qcoeff_ptr, qcoeff);

    int16x8_t dqcoeff = vmulq_s16(qcoeff, dequant);
    store_s16q_to_tran_low(dqcoeff_ptr, dqcoeff);

    uint16x8_t nz_mask = vtstq_s16(qcoeff, qcoeff);

    return nz_mask;
}

static inline void aom_quantize_b_helper_16x16_neon(const TranLow* coeff_ptr, intptr_t n_coeffs,
                                                    const int16_t* zbin_ptr, const int16_t* round_ptr,
                                                    const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                                    TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                                    const int16_t* dequant_ptr, uint16_t* eob_ptr,
                                                    const int16_t* iscan) {
    int16x8_t v_eobmax_76543210 = vdupq_n_s16(-1);

    int16x8_t v_zbins   = vdupq_n_s16(zbin_ptr[1]);
    int16x8_t v_round   = vdupq_n_s16(round_ptr[1]);
    int16x8_t v_dequant = vdupq_n_s16(dequant_ptr[1]);
    int16x8_t v_quant   = vdupq_n_s16(quant_ptr[1]);

    // The shift path is valid only because quant_shift is a power of two.
    assert(quant_shift_ptr[0] == (1 << svt_ctz((unsigned)quant_shift_ptr[0])));
    assert(quant_shift_ptr[1] == (1 << svt_ctz((unsigned)quant_shift_ptr[1])));
    int16x8_t v_neg_shift = vdupq_n_s16((int16_t)(svt_ctz((unsigned)quant_shift_ptr[1]) - 16));

    int16x8_t  v_zbins0 = vsetq_lane_s16(zbin_ptr[0], v_zbins, 0);
    int16x8_t  v_coeff  = load_tran_low_to_s16q(coeff_ptr);
    int16x8_t  v_abs    = vabsq_s16(v_coeff);
    uint16x8_t v_cond   = vcgeq_s16(v_abs, v_zbins0);

    uint16_t nz_check = vmaxvq_u16(v_cond);
    if (nz_check) {
        int16x8_t v_round0     = vsetq_lane_s16(round_ptr[0], v_round, 0);
        int16x8_t v_quant0     = vsetq_lane_s16(quant_ptr[0], v_quant, 0);
        int16x8_t v_dequant0   = vsetq_lane_s16(dequant_ptr[0], v_dequant, 0);
        int16x8_t v_neg_shift0 = vsetq_lane_s16((int16_t)(svt_ctz((unsigned)quant_shift_ptr[0]) - 16), v_neg_shift, 0);

        const uint16x8_t v_nz_mask = quantize_b_logscale0_8(
            v_coeff, v_abs, v_cond, v_round0, v_dequant0, v_quant0, v_neg_shift0, qcoeff_ptr, dqcoeff_ptr);

        int16x8_t v_iscan  = vld1q_s16(iscan);
        int16x8_t v_eobmax = vmaxq_s16(v_iscan, v_eobmax_76543210);
        v_eobmax_76543210  = vbslq_s16(v_nz_mask, v_eobmax, v_eobmax_76543210);
    } else {
        store_s16q_to_tran_low(qcoeff_ptr, vdupq_n_s16(0));
        store_s16q_to_tran_low(dqcoeff_ptr, vdupq_n_s16(0));
    }

    for (int i = 8; i < n_coeffs; i += 8) {
        v_coeff = load_tran_low_to_s16q(coeff_ptr + i);
        v_abs   = vabsq_s16(v_coeff);
        v_cond  = vcgeq_s16(v_abs, v_zbins);

        nz_check = vmaxvq_u16(v_cond);
        if (nz_check) {
            const uint16x8_t v_nz_mask = quantize_b_logscale0_8(
                v_coeff, v_abs, v_cond, v_round, v_dequant, v_quant, v_neg_shift, qcoeff_ptr + i, dqcoeff_ptr + i);

            int16x8_t v_iscan  = vld1q_s16(iscan + i);
            int16x8_t v_eobmax = vmaxq_s16(v_iscan, v_eobmax_76543210);
            v_eobmax_76543210  = vbslq_s16(v_nz_mask, v_eobmax, v_eobmax_76543210);
        } else {
            store_s16q_to_tran_low(qcoeff_ptr + i, vdupq_n_s16(0));
            store_s16q_to_tran_low(dqcoeff_ptr + i, vdupq_n_s16(0));
        }
    }
    *eob_ptr = vmaxvq_s16(v_eobmax_76543210) + 1;
}

static inline uint16x8_t quantize_b_logscale1_8(int16x8_t coeff, int16x8_t abs, uint16x8_t cond, int16x8_t round,
                                                int16x8_t dequant, int16x8_t quant, int16x8_t neg_shift,
                                                TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr) {
    int16x8_t coeff_sign = vreinterpretq_s16_u16(vcltzq_s16(coeff));

    int16x8_t tmp = vqaddq_s16(abs, round);
    tmp           = vsraq_n_s16(tmp, vqdmulhq_s16(tmp, quant), 1);
    tmp           = vshlq_s16(tmp, neg_shift);
    tmp           = vandq_s16(tmp, vreinterpretq_s16_u16(cond));

    int16x8_t qcoeff = vsubq_s16(veorq_s16(tmp, coeff_sign), coeff_sign);
    store_s16q_to_tran_low(qcoeff_ptr, qcoeff);

    // Shift by log_scale = 1.
    int16x8_t dqcoeff = vreinterpretq_s16_u16(vshrq_n_u16(vreinterpretq_u16_s16(vmulq_s16(tmp, dequant)), 1));
    dqcoeff           = vsubq_s16(veorq_s16(dqcoeff, coeff_sign), coeff_sign);
    store_s16q_to_tran_low(dqcoeff_ptr, dqcoeff);

    uint16x8_t nz_mask = vtstq_s16(qcoeff, qcoeff);

    return nz_mask;
}

static inline void aom_quantize_b_helper_32x32_neon(const TranLow* coeff_ptr, intptr_t n_coeffs,
                                                    const int16_t* zbin_ptr, const int16_t* round_ptr,
                                                    const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                                    TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                                    const int16_t* dequant_ptr, uint16_t* eob_ptr,
                                                    const int16_t* iscan) {
    const int log_scale = 1;
    const int zbins[2]  = {ROUND_POWER_OF_TWO(zbin_ptr[0], log_scale), ROUND_POWER_OF_TWO(zbin_ptr[1], log_scale)};
    const int rounds[2] = {ROUND_POWER_OF_TWO(round_ptr[0], log_scale), ROUND_POWER_OF_TWO(round_ptr[1], log_scale)};

    int16x8_t v_eobmax_76543210 = vdupq_n_s16(-1);

    int16x8_t v_zbins   = vdupq_n_s16(zbins[1]);
    int16x8_t v_round   = vdupq_n_s16(rounds[1]);
    int16x8_t v_dequant = vdupq_n_s16(dequant_ptr[1]);
    int16x8_t v_quant   = vdupq_n_s16(quant_ptr[1]);

    // The shift path is valid only because quant_shift is a power of two.
    assert(quant_shift_ptr[0] == (1 << svt_ctz((unsigned)quant_shift_ptr[0])));
    assert(quant_shift_ptr[1] == (1 << svt_ctz((unsigned)quant_shift_ptr[1])));
    int16x8_t v_neg_shift = vdupq_n_s16((int16_t)(svt_ctz((unsigned)quant_shift_ptr[1]) - (16 - log_scale)));

    int16x8_t  v_zbins0 = vsetq_lane_s16(zbins[0], v_zbins, 0);
    int16x8_t  v_coeff  = load_tran_low_to_s16q(coeff_ptr);
    int16x8_t  v_abs    = vabsq_s16(v_coeff);
    uint16x8_t v_cond   = vcgeq_s16(v_abs, v_zbins0);

    uint16_t nz_check = vmaxvq_u16(v_cond);
    if (nz_check) {
        int16x8_t v_round0     = vsetq_lane_s16(rounds[0], v_round, 0);
        int16x8_t v_quant0     = vsetq_lane_s16(quant_ptr[0], v_quant, 0);
        int16x8_t v_dequant0   = vsetq_lane_s16(dequant_ptr[0], v_dequant, 0);
        int16x8_t v_neg_shift0 = vsetq_lane_s16(
            (int16_t)(svt_ctz((unsigned)quant_shift_ptr[0]) - (16 - log_scale)), v_neg_shift, 0);

        const uint16x8_t v_nz_mask = quantize_b_logscale1_8(
            v_coeff, v_abs, v_cond, v_round0, v_dequant0, v_quant0, v_neg_shift0, qcoeff_ptr, dqcoeff_ptr);

        int16x8_t v_iscan  = vld1q_s16(iscan);
        int16x8_t v_eobmax = vmaxq_s16(v_iscan, v_eobmax_76543210);
        v_eobmax_76543210  = vbslq_s16(v_nz_mask, v_eobmax, v_eobmax_76543210);
    } else {
        store_s16q_to_tran_low(qcoeff_ptr, vdupq_n_s16(0));
        store_s16q_to_tran_low(dqcoeff_ptr, vdupq_n_s16(0));
    }

    for (int i = 8; i < n_coeffs; i += 8) {
        v_coeff = load_tran_low_to_s16q(coeff_ptr + i);
        v_abs   = vabsq_s16(v_coeff);
        v_cond  = vcgeq_s16(v_abs, v_zbins);

        nz_check = vmaxvq_u16(v_cond);
        if (nz_check) {
            const uint16x8_t v_nz_mask = quantize_b_logscale1_8(
                v_coeff, v_abs, v_cond, v_round, v_dequant, v_quant, v_neg_shift, qcoeff_ptr + i, dqcoeff_ptr + i);

            int16x8_t v_iscan  = vld1q_s16(iscan + i);
            int16x8_t v_eobmax = vmaxq_s16(v_iscan, v_eobmax_76543210);
            v_eobmax_76543210  = vbslq_s16(v_nz_mask, v_eobmax, v_eobmax_76543210);
        } else {
            store_s16q_to_tran_low(qcoeff_ptr + i, vdupq_n_s16(0));
            store_s16q_to_tran_low(dqcoeff_ptr + i, vdupq_n_s16(0));
        }
    }
    *eob_ptr = vmaxvq_s16(v_eobmax_76543210) + 1;
}

static inline uint16x8_t quantize_b_logscale2_8(int16x8_t coeff, int16x8_t abs, uint16x8_t cond, int16x8_t round,
                                                int16x8_t dequant, int16x8_t quant, int16x8_t neg_shift,
                                                TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr) {
    int16x8_t coeff_sign = vreinterpretq_s16_u16(vcltzq_s16(coeff));

    int16x8_t tmp = vqaddq_s16(abs, round);
    tmp           = vsraq_n_s16(tmp, vqdmulhq_s16(tmp, quant), 1);
    tmp           = vshlq_s16(tmp, neg_shift);
    tmp           = vandq_s16(tmp, vreinterpretq_s16_u16(cond));

    int16x8_t qcoeff = vsubq_s16(veorq_s16(tmp, coeff_sign), coeff_sign);
    store_s16q_to_tran_low(qcoeff_ptr, qcoeff);

    // Shift right by log_scale = 2.
    int16x8_t dqcoeff = vreinterpretq_s16_u16(vshrq_n_u16(vreinterpretq_u16_s16(vmulq_s16(tmp, dequant)), 2));
    dqcoeff           = vorrq_s16(vshlq_n_s16(vqdmulhq_s16(tmp, dequant), 13), dqcoeff);
    dqcoeff           = vsubq_s16(veorq_s16(dqcoeff, coeff_sign), coeff_sign);
    store_s16q_to_tran_low(dqcoeff_ptr, dqcoeff);

    uint16x8_t nz_mask = vtstq_s16(qcoeff, qcoeff);

    return nz_mask;
}

static inline void aom_quantize_b_helper_64x64_neon(const TranLow* coeff_ptr, intptr_t n_coeffs,
                                                    const int16_t* zbin_ptr, const int16_t* round_ptr,
                                                    const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                                                    TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr,
                                                    const int16_t* dequant_ptr, uint16_t* eob_ptr,
                                                    const int16_t* iscan) {
    const int log_scale = 2;
    const int zbins[2]  = {ROUND_POWER_OF_TWO(zbin_ptr[0], log_scale), ROUND_POWER_OF_TWO(zbin_ptr[1], log_scale)};
    const int rounds[2] = {ROUND_POWER_OF_TWO(round_ptr[0], log_scale), ROUND_POWER_OF_TWO(round_ptr[1], log_scale)};

    int16x8_t v_eobmax_76543210 = vdupq_n_s16(-1);

    int16x8_t v_zbins   = vdupq_n_s16(zbins[1]);
    int16x8_t v_round   = vdupq_n_s16(rounds[1]);
    int16x8_t v_dequant = vdupq_n_s16(dequant_ptr[1]);
    int16x8_t v_quant   = vdupq_n_s16(quant_ptr[1]);

    // The shift path is valid only because quant_shift is a power of two.
    assert(quant_shift_ptr[0] == (1 << svt_ctz((unsigned)quant_shift_ptr[0])));
    assert(quant_shift_ptr[1] == (1 << svt_ctz((unsigned)quant_shift_ptr[1])));
    int16x8_t v_neg_shift = vdupq_n_s16((int16_t)(svt_ctz((unsigned)quant_shift_ptr[1]) - (16 - log_scale)));

    int16x8_t  v_zbins0 = vsetq_lane_s16(zbins[0], v_zbins, 0);
    int16x8_t  v_coeff  = load_tran_low_to_s16q(coeff_ptr);
    int16x8_t  v_abs    = vabsq_s16(v_coeff);
    uint16x8_t v_cond   = vcgeq_s16(v_abs, v_zbins0);

    uint16_t nz_check = vmaxvq_u16(v_cond);
    if (nz_check) {
        int16x8_t v_round0     = vsetq_lane_s16(rounds[0], v_round, 0);
        int16x8_t v_quant0     = vsetq_lane_s16(quant_ptr[0], v_quant, 0);
        int16x8_t v_dequant0   = vsetq_lane_s16(dequant_ptr[0], v_dequant, 0);
        int16x8_t v_neg_shift0 = vsetq_lane_s16(
            (int16_t)(svt_ctz((unsigned)quant_shift_ptr[0]) - (16 - log_scale)), v_neg_shift, 0);

        const uint16x8_t v_nz_mask = quantize_b_logscale2_8(
            v_coeff, v_abs, v_cond, v_round0, v_dequant0, v_quant0, v_neg_shift0, qcoeff_ptr, dqcoeff_ptr);

        int16x8_t v_iscan  = vld1q_s16(iscan);
        int16x8_t v_eobmax = vmaxq_s16(v_iscan, v_eobmax_76543210);
        v_eobmax_76543210  = vbslq_s16(v_nz_mask, v_eobmax, v_eobmax_76543210);
    } else {
        store_s16q_to_tran_low(qcoeff_ptr, vdupq_n_s16(0));
        store_s16q_to_tran_low(dqcoeff_ptr, vdupq_n_s16(0));
    }

    for (int i = 8; i < n_coeffs; i += 8) {
        v_coeff = load_tran_low_to_s16q(coeff_ptr + i);
        v_abs   = vabsq_s16(v_coeff);
        v_cond  = vcgeq_s16(v_abs, v_zbins);

        nz_check = vmaxvq_u16(v_cond);
        if (nz_check) {
            const uint16x8_t v_nz_mask = quantize_b_logscale2_8(
                v_coeff, v_abs, v_cond, v_round, v_dequant, v_quant, v_neg_shift, qcoeff_ptr + i, dqcoeff_ptr + i);

            int16x8_t v_iscan  = vld1q_s16(iscan + i);
            int16x8_t v_eobmax = vmaxq_s16(v_iscan, v_eobmax_76543210);
            v_eobmax_76543210  = vbslq_s16(v_nz_mask, v_eobmax, v_eobmax_76543210);
        } else {
            store_s16q_to_tran_low(qcoeff_ptr + i, vdupq_n_s16(0));
            store_s16q_to_tran_low(dqcoeff_ptr + i, vdupq_n_s16(0));
        }
    }
    *eob_ptr = vmaxvq_s16(v_eobmax_76543210) + 1;
}

void svt_aom_quantize_b_neon(const TranLow* coeff_ptr, intptr_t n_coeffs, const int16_t* zbin_ptr,
                             const int16_t* round_ptr, const int16_t* quant_ptr, const int16_t* quant_shift_ptr,
                             TranLow* qcoeff_ptr, TranLow* dqcoeff_ptr, const int16_t* dequant_ptr, uint16_t* eob_ptr,
                             const int16_t* scan, const int16_t* iscan, const QmVal* qm_ptr, const QmVal* iqm_ptr,
                             const int log_scale) {
    assert(qm_ptr == NULL);
    assert(iqm_ptr == NULL);
    (void)scan;
    (void)qm_ptr;
    (void)iqm_ptr;

    // log_scale for AV1 encoder can be only 0, 1, 2
    switch (log_scale) {
    case 0: {
        aom_quantize_b_helper_16x16_neon(coeff_ptr,
                                         n_coeffs,
                                         zbin_ptr,
                                         round_ptr,
                                         quant_ptr,
                                         quant_shift_ptr,
                                         qcoeff_ptr,
                                         dqcoeff_ptr,
                                         dequant_ptr,
                                         eob_ptr,
                                         iscan);
        break;
    }
    case 1: {
        aom_quantize_b_helper_32x32_neon(coeff_ptr,
                                         n_coeffs,
                                         zbin_ptr,
                                         round_ptr,
                                         quant_ptr,
                                         quant_shift_ptr,
                                         qcoeff_ptr,
                                         dqcoeff_ptr,
                                         dequant_ptr,
                                         eob_ptr,
                                         iscan);
        break;
    }
    case 2: {
        aom_quantize_b_helper_64x64_neon(coeff_ptr,
                                         n_coeffs,
                                         zbin_ptr,
                                         round_ptr,
                                         quant_ptr,
                                         quant_shift_ptr,
                                         qcoeff_ptr,
                                         dqcoeff_ptr,
                                         dequant_ptr,
                                         eob_ptr,
                                         iscan);
        break;
    }
    }
}

int32_t svt_av1_compute_cul_level_neon(const int16_t* const scan, const int32_t* const quant_coeff, int32_t eob,
                                       int32_t n_coeffs) {
    int32x4_t sum_s32[2] = {vdupq_n_s32(0), vdupq_n_s32(0)};

    if (eob * 12 < n_coeffs) {
        // Sparse: scan-based gather, bounded by eob.
        int32x4_t      zeros    = vdupq_n_s32(0);
        int32_t        sz       = eob;
        const int16_t* scan_ptr = scan;
        while (sz >= 8) {
            const int32_t quant_coeff0 = quant_coeff[scan_ptr[0]];
            const int32_t quant_coeff1 = quant_coeff[scan_ptr[1]];
            const int32_t quant_coeff2 = quant_coeff[scan_ptr[2]];
            const int32_t quant_coeff3 = quant_coeff[scan_ptr[3]];
            const int32_t quant_coeff4 = quant_coeff[scan_ptr[4]];
            const int32_t quant_coeff5 = quant_coeff[scan_ptr[5]];
            const int32_t quant_coeff6 = quant_coeff[scan_ptr[6]];
            const int32_t quant_coeff7 = quant_coeff[scan_ptr[7]];

            int32x4_t quant_coeff_0123 = vcombine_s32(
                vcreate_s32((((uint64_t)quant_coeff1) << 32) | (uint32_t)quant_coeff0),
                vcreate_s32((((uint64_t)quant_coeff3) << 32) | (uint32_t)quant_coeff2));

            int32x4_t quant_coeff_4567 = vcombine_s32(
                vcreate_s32((((uint64_t)quant_coeff5) << 32) | (uint32_t)quant_coeff4),
                vcreate_s32((((uint64_t)quant_coeff7) << 32) | (uint32_t)quant_coeff6));

            sum_s32[0] = vabaq_s32(sum_s32[0], quant_coeff_0123, zeros);
            sum_s32[1] = vabaq_s32(sum_s32[1], quant_coeff_4567, zeros);

            scan_ptr += 8;
            sz -= 8;
        }

        if (sz >= 4) {
            const int32_t quant_coeff0 = quant_coeff[scan_ptr[0]];
            const int32_t quant_coeff1 = quant_coeff[scan_ptr[1]];
            const int32_t quant_coeff2 = quant_coeff[scan_ptr[2]];
            const int32_t quant_coeff3 = quant_coeff[scan_ptr[3]];

            int32x4_t quant_coeff_0123 = vcombine_s32(
                vcreate_s32((((uint64_t)quant_coeff1) << 32) | (uint32_t)quant_coeff0),
                vcreate_s32((((uint64_t)quant_coeff3) << 32) | (uint32_t)quant_coeff2));

            sum_s32[0] = vabaq_s32(sum_s32[0], quant_coeff_0123, zeros);

            scan_ptr += 4;
            sz -= 4;
        }

        int sum = 0;
        while (sz) {
            sum += abs(quant_coeff[*scan_ptr]);
            scan_ptr++;
            sz--;
        }
        return sum + vaddvq_s32(vaddq_s32(sum_s32[0], sum_s32[1]));
    }

    // Dense: gather-free linear over the whole block. n_coeffs is always a multiple of 16.
    assert(n_coeffs % 8 == 0);
    for (int32_t i = 0; i < n_coeffs; i += 8) {
        sum_s32[0] = vaddq_s32(sum_s32[0], vabsq_s32(vld1q_s32(quant_coeff + i)));
        sum_s32[1] = vaddq_s32(sum_s32[1], vabsq_s32(vld1q_s32(quant_coeff + i + 4)));
    }
    return vaddvq_s32(vaddq_s32(sum_s32[0], sum_s32[1]));
}
